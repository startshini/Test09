package com.example.dfs

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.github.mikephil.charting.charts.LineChart
import java.io.*
import java.lang.NumberFormatException
import java.util.*

class frmWeightGraph : AppCompatActivity() {
    private lateinit var file: File

    // 制作者：石原慎一
    // 関数の説明：入力された体重と今までに入力された体重を用いて，体重の推移をグラフで表現する.
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_frm_weight_graph)

        val textView = findViewById<TextView>(R.id.stateText)
        val editText = findViewById<EditText>(R.id.weightInput)
        val buttonSave = findViewById<Button>(R.id.ButtonSave)
        val context: Context = applicationContext

        // 日時取得
        val calendar: Calendar = Calendar.getInstance(TimeZone.getTimeZone("Asia/Tokyo"), Locale.JAPAN)
        val nowDate: String = calendar.get(Calendar.YEAR).toString() + "-" + (calendar.get(Calendar.MONTH) + 1).toString() + "-" + calendar.get(
            Calendar.DAY_OF_MONTH).toString()

        val lineChart = findViewById<LineChart>(R.id.lineChart)

        // 起動時グラフ生成処理
        try {
            file = File(context.filesDir, "weight.txt")
            WeightGraphDraw.graphDraw(lineChart, file)
        } catch (e: NumberFormatException) {
            saveFile("weight.txt", "0\t"+nowDate)
            file = File(context.filesDir, "weight.txt")
            WeightGraphDraw.graphDraw(lineChart, file)
        }

        // 保存ボタン処理
        buttonSave.setOnClickListener {
            val date: String = calendar.get(Calendar.YEAR)
                .toString() + "-" + (calendar.get(Calendar.MONTH) + 1).toString() + "-" + calendar.get(
                Calendar.DAY_OF_MONTH
            ).toString()
            // エディットテキストのテキストを取得
            val text = editText.text.toString()
            if (text.isEmpty()){
                textView.setText(R.string.no_text)
            } else if(text.toDouble() <= 0 || text.toDouble() > 300) {
                editText.text = null
                textView.text = "Enter properly"
            } else {
                val dataList: List<String> = listOf(text, date)
                file = File(context.filesDir, "weight.txt")
                editText.text = null
                // 体重データ保存
                WeightDataProc.saveArrayFile(dataList, file)
                textView.setText(R.string.saved)
                file = File(context.filesDir, "weight.txt")
                // 体重グラフ出力
                WeightGraphDraw.graphDraw(lineChart, file)
            }
        }

        val calBt : Button = findViewById(R.id.calBt)
        val traBt : Button = findViewById(R.id.traBt)
        val graBt : Button = findViewById(R.id.graBt)
        val remBt : Button = findViewById(R.id.remBt)

        calBt.setOnClickListener {
            val intent = Intent(this,frmCalorieView::class.java)
            startActivity(intent)
        }

        traBt.setOnClickListener {
            val intent = Intent(this,frmTrainingView::class.java)
            startActivity(intent)
        }

        graBt.setOnClickListener {
            val intent = Intent(this,frmWeightGraph::class.java)
            startActivity(intent)
        }

        remBt.setOnClickListener {
            val intent = Intent(this,frmRemindView::class.java)
            startActivity(intent)
        }
    }

    // 制作者：石原慎一
    // 関数の説明：ファイル書き込み
    private fun saveFile(fileName: String, num: String) {
        try {
            openFileOutput( fileName, Context.MODE_PRIVATE).use {
                    fileOutputstream -> fileOutputstream.write(num.toByteArray()) }
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }
}