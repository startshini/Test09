package com.example.dfs

import android.annotation.SuppressLint
import android.content.*
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import java.io.*
import java.nio.charset.StandardCharsets
import java.util.*

import kotlin.NumberFormatException

class frmCalorieView : AppCompatActivity() {

    private var temp: ArrayList<String> = arrayListOf()

    @SuppressLint("MissingInflatedId", "SuspiciousIndentation")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_frm_calorie_view)

        //viewから取得
        val calBt: Button = findViewById(R.id.calBt)
        val traBt: Button = findViewById(R.id.traBt)
        val graBt: Button = findViewById(R.id.graBt)
        val remBt: Button = findViewById(R.id.remBt)
        val infBt: Button = findViewById(R.id.infBt)
        val intBT: Button = findViewById(R.id.intBt)
        val burBt: Button = findViewById(R.id.burBt)
        val limText: TextView = findViewById(R.id.limText)
        val intText: TextView = findViewById(R.id.intText)
        val burText: TextView = findViewById(R.id.burText)
        val difText: TextView = findViewById(R.id.difText)

        var Calorie: Int
        //日付の取得
        val calendar: Calendar = Calendar.getInstance(TimeZone.getTimeZone("Asia/Tokyo"), Locale.JAPAN)
        val date: String = calendar.get(Calendar.YEAR).toString() + "-" + (calendar.get(Calendar.MONTH) + 1).toString() + "-" + calendar.get(Calendar.DAY_OF_MONTH).toString()

        //ユーザの一日に摂れるカロリーの限界値を表示
        var file = "limitCalorie.txt"
        try {
            Calorie = readFile(file).toString().toInt()
        } catch (e: NumberFormatException) {
            saveFile(file, "0")
            Calorie = 0
        } catch (e: FileNotFoundException) {
            saveFile(file, "0")
            Calorie = 0
        }
        limText.text = "${Calorie}"

        file = "intakeCalorie.txt"
        var fileName = "intakeCalorieInfo.txt"

        //摂取カロリーが入力された日が当日でなければ０に書き換える
        try {
            if (!(searchDate(fileName, date))) {
                saveFile(file, "0")
                saveFile("mealInformation.txt", "")
            }
        } catch (e: FileNotFoundException) {
            saveFile(file, "0")
            saveFile("mealInformation.txt", "")
        }

        //当日の摂取カロリーの表示
        try {
            Calorie = readFile(file).toString().toInt()
        } catch (e: NumberFormatException) {
            saveFile(file, "0")
            Calorie = 0
        } catch (e: FileNotFoundException) {
            saveFile(file, "0")
            Calorie = 0
        }

        intText.text = "$Calorie"

        file = "burnedCalorie.txt"
        fileName = "burnedCalorieInfo.txt"

        //消費カロリ―が入力された当日でなければ０に書き換える
        try {
            if(!(searchDate(fileName, date))) {
                saveFile(file,"0")
            }
        } catch (e: FileNotFoundException) {
            saveFile(file, "0")
        }

        //当日の消費カロリーの表示
        try {
            Calorie = readFile(file).toString().toInt()
        } catch (e: NumberFormatException) {
            saveFile(file, "0")
            Calorie = 0
        } catch (e: FileNotFoundException) {
            saveFile(file, "0")
            Calorie = 0
        }
        burText.text = "$Calorie"

        //当日あとどれほどカロリーを摂取して良いかの表示
        if(Calculation().difCalc(limText.text.toString().toInt(), intText.text.toString().toInt(), burText.text.toString().toInt()) <= 0) {
            difText.text = "もう食べちゃだめ"
        }
        else {
            difText.text = Calculation().difCalc(limText.text.toString().toInt(), intText.text.toString().toInt(), burText.text.toString().toInt()).toString()
        }

        //押したボタンに対応した画面に遷移する
        calBt.setOnClickListener {
            val intent = Intent(this, frmCalorieView::class.java)
            startActivity(intent)
        }

        traBt.setOnClickListener {
            val intent = Intent(this, frmTrainingView::class.java)
            startActivity(intent)
        }

        graBt.setOnClickListener {
            val intent = Intent(this, frmWeightGraph::class.java)
            startActivity(intent)
        }

        remBt.setOnClickListener {
            val intent = Intent(this, frmRemindView::class.java)
            startActivity(intent)
        }

        infBt.setOnClickListener {
            val intent = Intent(this, frmUserInfoInput::class.java)
            startActivity(intent)
        }

        intBT.setOnClickListener {
            val intent = Intent(this, frmCalorieIntakeInput::class.java)
            startActivity(intent)
        }

        burBt.setOnClickListener {
            val intent = Intent(this, frmCalorieBurnedInput::class.java)
            startActivity(intent)
        }
    }

    //ファイル書き込み
    private fun saveFile(fileName: String, str: String) {
        try {
            openFileOutput( fileName, Context.MODE_PRIVATE).use {
                    fileOutputstream -> fileOutputstream.write(str.toByteArray()) }
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    //ファイル読み込み
    private fun readFile(fileName: String): String? {
        var text: String? = null

        try {
            openFileInput(fileName).use { fileInputStream ->
                BufferedReader(
                    InputStreamReader(fileInputStream, StandardCharsets.UTF_8)
                ).use { reader ->
                    var lineBuffer: String?
                    while (reader.readLine().also { lineBuffer = it } != null) {
                        text = lineBuffer
                    }
                }
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }
        return text
    }

    //入力されているカロリーが当日のものか判断する関数
    private fun searchDate(fileName: String, date: String): Boolean {
        try {
            openFileInput(fileName).use { fileInputStream ->
                BufferedReader(
                    InputStreamReader(fileInputStream, StandardCharsets.UTF_8)
                ).use { br ->
                    var lineBuffer: String?
                    while (br.readLine().also { lineBuffer = it } != null) {
                        if(lineBuffer.equals(date)) {
                            return true
                        }
                    }
                }
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }
        return false
    }
}