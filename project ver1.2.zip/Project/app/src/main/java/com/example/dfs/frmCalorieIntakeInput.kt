package com.example.dfs

import android.content.*
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import java.io.*
import java.lang.IndexOutOfBoundsException
import java.lang.NullPointerException
import java.nio.charset.StandardCharsets
import java.util.*
import kotlin.collections.ArrayList

class frmCalorieIntakeInput : AppCompatActivity() {

    private fun insert_value(value : String){ //引数２つを横に並べる
        val text_in = findViewById<LinearLayout>(R.id.text_in)   //縦のレイアウト
        //val text_hor = findViewById<LinearLayout>(R.id.text_hor)  //横のレイアウト
        val textView = TextView(this)
        val sp = Space(this)
        textView.text = value
        text_in.addView(textView)  //in->horに変更した
        text_in.addView(sp, FrameLayout.LayoutParams(300, 10))
        //val sp = Space(this)
        //text_hor.addView(sp, FrameLayout.LayoutParams(40, 40))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_frm_calorie_intake_input)

        val backBt : Button = findViewById(R.id.backBt)  //完了ボタン
        val addBt : Button = findViewById(R.id.addBt)    //入力ボタン
        val intakeInput : EditText = findViewById(R.id.IntakeInput)    //カロリーinput
        val takemealInput: EditText = findViewById(R.id.TakeMealInput) //食事input
        var i : Int = 1 //メニューの番号
        var intakeNum = readFile("intakeCalorie.txt").toString().toInt()
        val calendar: Calendar = Calendar.getInstance(TimeZone.getTimeZone("Asia/Tokyo"), Locale.JAPAN)
        val date: String = calendar.get(Calendar.YEAR).toString() + "-" + (calendar.get(Calendar.MONTH) + 1).toString() + "-" + calendar.get(Calendar.DAY_OF_MONTH).toString()
        var meal: ArrayList<String> = arrayListOf()
        var error = 0
        val line = "----------------------------------------------------------------------------------------"

        try {
            meal = returnMealFile("mealInformation.txt")
            for(str in meal) {
                insert_value(str)
            }
            i = meal.size / 2 + 1
        } catch (e: FileNotFoundException) {
            saveFile("mealInformation.txt", "")
        } catch (e: IndexOutOfBoundsException) {
            saveFile("mealInformation.txt", "")
        }

        addBt.setOnClickListener {
            if (intakeInput.text.toString().equals("") || takemealInput.text.toString()
                    .equals("")
            ) {
                AlertDialog.Builder(this).setTitle("Error!").setMessage("正しく項目を埋めてください")
                    .setPositiveButton("OK", null).show()
            } else {
                intakeNum += intakeInput.text.toString().toInt()
                val menu = "メニュー" + i + "：" + takemealInput.getText().toString() +
                        "  --------->  " + intakeInput.getText().toString() + "kcal"
                insert_value(menu)
                meal.add("${menu}\n")
                insert_value(line)
                meal.add("${line}\n")
                addToFile("mealInformation.txt", "${menu}\n${line}\n")
                //insert_value(intakeInput.getText().toString() + "kcal")
                intakeInput.text = null
                takemealInput.text = null
                i = i + 1
                val intakeInfo: String =
                    intakeNum.toString() + "\n" + date + "\n" + calendar.get(Calendar.HOUR_OF_DAY)
                        .toString() + "\n" + calendar.get(Calendar.MINUTE).toString()
                saveFile("intakeCalorie.txt", intakeNum.toString())
                saveFile("intakeCalorieInfo.txt", intakeInfo)
                intakeInput.text = null
            }
        }
        backBt.setOnClickListener {
            saveFile("intakeCalorie.txt",intakeNum.toString())
            val intent = Intent(this, frmCalorieView::class.java)
            startActivity(intent)
        }
    }

    //テキストファイルに上書き保存
    private fun saveFile(fileName: String, str: String) {
        try {
            openFileOutput( fileName, Context.MODE_PRIVATE).use {
                    fileOutputstream -> fileOutputstream.write(str.toByteArray()) }
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    //テキストファイルから一行読み込む
    private fun readFile(fileName: String): String? {
        var text: String? = null

        try {
            openFileInput(fileName).use { fileInputStream ->
                BufferedReader(
                    InputStreamReader(fileInputStream, StandardCharsets.UTF_8)
                ).use { reader ->
                    var lineBuffer: String?
                    while (reader.readLine().also { lineBuffer = it } != null) {
                        text = lineBuffer
                    }
                }
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }
        return text
    }

    //テキストファイルへ追記する
    private fun addToFile(fileName: String, str: String) {
        try {
            openFileOutput( fileName, Context.MODE_APPEND).use {
                    fileOutputstream -> fileOutputstream.write(str.toByteArray()) }
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    //テキストファイルを読み込みリストにして返す
    private fun returnMealFile(fileName: String): ArrayList<String> {
        val text: ArrayList<String> = arrayListOf()

        try {
            openFileInput(fileName).use { fileInputStream ->
                BufferedReader(
                    InputStreamReader(fileInputStream, StandardCharsets.UTF_8)
                ).use { reader ->
                    var lineBuffer: String?
                    while (reader.readLine().also { lineBuffer = it } != null) {
                        text.add(lineBuffer.toString())
                    }
                }
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }
        return text
    }
}