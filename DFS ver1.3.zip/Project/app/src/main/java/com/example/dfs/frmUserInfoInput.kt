package com.example.dfs

import android.content.*
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import java.io.*
import java.nio.charset.StandardCharsets
import java.util.*
import kotlin.collections.ArrayList

class frmUserInfoInput : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_frm_user_info_input)

        //Viewの取得
        val backBt : Button = findViewById(R.id.backBt)
        val BirInp : EditText = findViewById(R.id.BirInp)
        val HeiInp : EditText = findViewById(R.id.HeiInp)
        val WeiInp : EditText = findViewById(R.id.WeiInp)
        val Gender : RadioGroup = findViewById(R.id.Gender)
        val Prof : TextView = findViewById(R.id.profile)
        var gender : Int = -1
        var age : Int
        var error: Int = 0
        val calendar: Calendar = Calendar.getInstance(TimeZone.getTimeZone("Asia/Tokyo"), Locale.JAPAN)
        val nowDate: String = calendar.get(Calendar.YEAR).toString() + "-" + (calendar.get(Calendar.MONTH) + 1).toString() + "-" + calendar.get(
            Calendar.DAY_OF_MONTH).toString()
        val context: Context = applicationContext
        val profile: ArrayList<String> = readFile("userProfile.txt")

        if(profile[0] == "") {
            Prof.text = "あなたの情報を教えてください\n生年月日は2002/05/11のように、生まれた年/生まれた月/生まれた日と入力してください"
        }
        else {
            Prof.text = "あなたのプロフィール\n" + "年齢 : " + profile[0] + "\n性別 : " + profile[1] + "\n身長 : " + profile[2] + "\n体重 : " + profile[3]
        }

        //ラジオボタンによる性別の確認
        Gender.setOnCheckedChangeListener { group, checkedId ->
            if(checkedId == R.id.male) {
                gender = 0
            }
            if(checkedId == R.id.female) {
                gender = 1
            }
        }

        //完了ボタンを押した際の処理
        backBt.setOnClickListener {
            val BirthDate = BirInp.text.toString()
            //生年月日から年齢の計算
            age = Calculation().ageCalc(BirthDate)
            if(age == -1) {
                error = 1
            }

            if(WeiInp.text.toString().length == 0 || HeiInp.text.toString().length == 0) {
                error = 1
            }

            val weight : Double = WeiInp.text.toString().toDouble()
            val height : Double = HeiInp.text.toString().toDouble()
            val text: ArrayList<String> = arrayListOf()
            text.add(weight.toString())

            if(gender == -1 ||weight < 0 || weight > 300 || height < 0 || height > 300) {
                error = 1
            }
            if(error == 0) {
                //一日に摂取できるカロリーを計算
                val limitNum = Calculation().limitCalorieCalc(weight, height, age, gender)
                var genderName:String = " "
                if(gender == 0){
                    genderName = "男性"
                }else {
                    genderName = "女性"
                }

                val prof: String = age.toString() + "\n" +genderName + "\n" + height.toString() + "\n" +weight.toString()
                saveFile("userProfile.txt", prof)
                saveFile("limitCalorie.txt", limitNum.toString())
                val file1 = File(context.filesDir, "weight.txt")
                try {
                    BufferedWriter(FileWriter(file1)).use { writer ->
                        val lines = text.size - 1
                        for (i in 0..lines) {
                            writer.write(text[i]+"\t"+nowDate)
                        }
                    }
                } catch (e: IOException) {
                    e.printStackTrace()
                }

                val intent = Intent(this, frmCalorieView::class.java)
                startActivity(intent)
            }else {
                //入力ミスがあった場合アラートダイアログの表示
                AlertDialog.Builder(this).setTitle("Error!").setMessage("正しく項目を埋めてください").setPositiveButton("OK",null).show()
                error = 0
            }
        }
    }

    //ファイル書き込み
    private fun saveFile(fileName: String, num: String) {
        try {
            openFileOutput( fileName, Context.MODE_PRIVATE).use {
                    fileOutputstream -> fileOutputstream.write(num.toByteArray()) }
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    //ファイル読み込み
    private fun readFile(fileName: String): ArrayList<String> {
        var text: ArrayList<String> = arrayListOf()

        try {
            openFileInput(fileName).use { fileInputStream ->
                BufferedReader(
                    InputStreamReader(fileInputStream, StandardCharsets.UTF_8)
                ).use { br ->
                    var line = br.readLine()
                    while(line != null) {
                        text.add(line)
                        line = br.readLine()
                    }
                }
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }
        return text
    }
}