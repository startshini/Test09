package com.example.dfs

import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.io.FileReader
import java.io.FileWriter
import java.io.IOException
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

class WeightDataProc {

    companion object {
        // RemindStrファイルを保存
        fun saveArrayFile(datalist:List<String>, file: File) {
            val calendar: Calendar = Calendar.getInstance(TimeZone.getTimeZone("Asia/Tokyo"), Locale.JAPAN)
            val nowDate: String = calendar.get(Calendar.YEAR).toString() + "-" + (calendar.get(Calendar.MONTH) + 1).toString() + "-" + calendar.get(
                Calendar.DAY_OF_MONTH).toString()
            val tmplist: ArrayList<String> = ArrayList()

            try {
                BufferedReader(FileReader(file)).use { br ->
                    var line = br.readLine()
                    while (line != null) {
                        tmplist.add(line)
                        line = br.readLine()
                    }
                }
            } catch (e: IOException) {
                e.printStackTrace()
            }

            val str: String = tmplist[tmplist.size - 1]
            val lastLine = str.split("\t")
            if (lastLine[1] == nowDate){
                try {
                    BufferedWriter(FileWriter(file, true)).use { writer ->
                        val lines = tmplist.size - 2
                        for (i in 0..lines) {
                            writer.write(tmplist[i])
                            writer.newLine()
                        }
                        writer.write(datalist[0]+"\t"+datalist[1])
                    }
                } catch (e: IOException) {
                    e.printStackTrace()
                }
            }else {
                try {
                    BufferedWriter(FileWriter(file, true)).use { writer ->
                        val lines = tmplist.size - 1
                        for (i in 0..lines) {
                            writer.write(tmplist[i])
                            writer.newLine()
                        }
                        writer.write(datalist[0]+"\t"+datalist[1])
                    }
                } catch (e: IOException) {
                    e.printStackTrace()
                }
            }
        }

        // RemindStrファイルを読み出し
        fun readArrayFile(file: File): ArrayList<String> {
            val text: ArrayList<String> = arrayListOf()
            try {
                BufferedReader(FileReader(file)).use { br ->
                    var line = br.readLine()
                    while (line != null) {
                        text.add(line)
                        line = br.readLine()
                    }
                }
            } catch (e: IOException) {
                e.printStackTrace()
            }
            return text
        }
    }
}