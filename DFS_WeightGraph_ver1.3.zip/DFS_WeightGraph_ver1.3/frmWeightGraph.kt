@file:Suppress("ClassName")

package com.example.dfs

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.formatter.ValueFormatter
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

class frmWeightGraph : AppCompatActivity() {
    private lateinit var file1: File

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_frm_weight_graph)

        val textView = findViewById<TextView>(R.id.stateText)
        val editText = findViewById<EditText>(R.id.weightInput)
        val buttonSave = findViewById<Button>(R.id.ButtonSave)
        val context: Context = applicationContext

        buttonSave.setOnClickListener {
            val calendar: Calendar = Calendar.getInstance(TimeZone.getTimeZone("Asia/Tokyo"), Locale.JAPAN)
            val date: String = calendar.get(Calendar.YEAR).toString() + "-" + (calendar.get(Calendar.MONTH) + 1).toString() + "-" + calendar.get(
                Calendar.DAY_OF_MONTH).toString()
            // エディットテキストのテキストを取得
            val text = editText.text.toString()
            val datalist: List<String> = listOf(text, date)
            file1 = File(context.filesDir, "weight.txt")
            WeightDataProc.saveArrayFile(datalist, file1)
            if (text.isEmpty()) textView.setText(R.string.no_text)
            else textView.setText(R.string.saved)

            //グラフに表示するためのデータを格納
            var entries = ArrayList<Entry>()
            val list = WeightDataProc.readArrayFile(file1)
            list.reverse()

            val saveDate = ArrayList<String>()
            for (i in 0..10) {
                if (list[i] == null) {
                    entries.add(Entry(i.toFloat(), 0f))
                } else {
                    val text = list[i].split("\t")
                    entries.add(Entry(i.toFloat(), text[0].toFloat()))
                    saveDate.add(text[1])
                }
            }

            //表示するデータをDataSetに追加
            val dataSet = LineDataSet(entries, "Label")

            //DataSetをDataに追加
            val data = LineData(dataSet)

            //ビューを取得
            val chart = findViewById<LineChart>(R.id.chart)

            //ChartにDataを追加
            chart.data = data

            val lineDataSet = LineDataSet(entries, "chart")
            lineDataSet.setDrawValues(false)

            chart.data = LineData(mutableListOf<ILineDataSet>(lineDataSet))
            chart.setDrawGridBackground(false)
            chart.description.isEnabled = false

            chart.legend.apply {
                isEnabled = false
            }

            // X 軸のフォーマッター
            val xAxisFormatter = object : ValueFormatter() {
                private var simpleDateFormat: SimpleDateFormat =
                    SimpleDateFormat("M/d", Locale.getDefault())

                override fun getFormattedValue(value: Float): String {
                    val date = saveDate[value.toInt()]
                    return simpleDateFormat.format(date)
                }
            }

            // X 軸の設定
            chart.xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                valueFormatter = xAxisFormatter
                setDrawGridLines(false)
            }

            // Y 軸（左）の設定
            chart.axisLeft.apply {
                setDrawGridLines(true)
                axisMinimum = 0f
            }

            // Y 軸（右）の設定
            chart.axisRight.apply {
                isEnabled = false
            }

            //チャートを更新
            chart.invalidate()
        }

        val calBt : Button = findViewById(R.id.calBt)
        val traBt : Button = findViewById(R.id.traBt)
        val graBt : Button = findViewById(R.id.graBt)
        val remBt : Button = findViewById(R.id.remBt)

        calBt.setOnClickListener {
            val intent = Intent(this,frmCalorieView::class.java)
            startActivity(intent)
        }

        traBt.setOnClickListener {
            val intent = Intent(this,frmTrainingView::class.java)
            startActivity(intent)
        }

        graBt.setOnClickListener {
            val intent = Intent(this,frmWeightGraph::class.java)
            startActivity(intent)
        }

        remBt.setOnClickListener {
            val intent = Intent(this,frmRemindView::class.java)
            startActivity(intent)
        }
    }
}