package com.example.dfs

import android.content.*
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import java.io.*
import java.lang.IndexOutOfBoundsException
import java.nio.charset.StandardCharsets
import java.util.*
import kotlin.collections.ArrayList

class frmUserInfoInput : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_frm_user_info_input)

        //Viewの取得
        val backBt : Button = findViewById(R.id.backBt)
        val backbt2 : Button = findViewById(R.id.backbt2)
        val BirInp : EditText = findViewById(R.id.BirInp)
        val HeiInp : EditText = findViewById(R.id.HeiInp)
        val WeiInp : EditText = findViewById(R.id.WeiInp)
        val Gender : RadioGroup = findViewById(R.id.Gender)
        val Prof : TextView = findViewById(R.id.profile)
        var gender : Int = -1
        var age : Int = -1
        var error: Int = 0
        var height: Double = -1.0
        var weight: Double = -1.0
        val calendar: Calendar = Calendar.getInstance(TimeZone.getTimeZone("Asia/Tokyo"), Locale.JAPAN)
        val nowDate: String = calendar.get(Calendar.YEAR).toString() + "-" + (calendar.get(Calendar.MONTH) + 1).toString() + "-" + calendar.get(
            Calendar.DAY_OF_MONTH).toString()
        val context: Context = applicationContext
        var profile: ArrayList<String> = arrayListOf()

        try {
            profile = readFile("userProfile.txt")
            Prof.text = "あなたのプロフィール\n" + "年齢 : " + profile[0] + "\n性別 : " + profile[1] + "\n身長 : " + profile[2] + "\n体重 : " + profile[3]
        } catch (e: FileNotFoundException) {
            Prof.text = "あなたの情報を教えてください\n生年月日は2002/05/11のように、生まれた年/生まれた月/生まれた日と入力してください"
            saveFile("userProfile.txt", "")
        } catch (e: IndexOutOfBoundsException)  {
            Prof.text = "あなたの情報を教えてください\n生年月日は2002/05/11のように、生まれた年/生まれた月/生まれた日と入力してください"
            saveFile("userProfile.txt", "")
        }

        //ラジオボタンによる性別の確認
        Gender.setOnCheckedChangeListener { group, checkedId ->
            if(checkedId == R.id.male) {
                gender = 0
            }
            if(checkedId == R.id.female) {
                gender = 1
            }
        }

        //完了ボタンを押した際の処理
        backBt.setOnClickListener {
            val BirthDate = BirInp.text.toString()
            //生年月日から年齢の計算
            if(!(BirthDate.equals(""))) {
                age = Calculation().ageCalc(BirthDate)
            }
            if(age == -1) {
                error = 1
            }

            if(WeiInp.text.toString().equals("") || HeiInp.text.toString().equals("")) {
                error = 1
            } else {
                weight = WeiInp.text.toString().toDouble()
                height = HeiInp.text.toString().toDouble()
            }

            if(gender == -1 ||weight < 0 || weight > 300 || height < 0 || height > 300) {
                error = 1
            }
            if(error == 0) {
                //一日に摂取できるカロリーを計算
                val limitNum = Calculation().limitCalorieCalc(weight, height, age, gender)
                var genderName:String = " "
                if(gender == 0){
                    genderName = "男性"
                }else {
                    genderName = "女性"
                }

                val prof: String = age.toString() + "\n" +genderName + "\n" + height.toString() + "\n" +weight.toString()
                saveFile("userProfile.txt", prof)
                saveFile("limitCalorie.txt", limitNum.toString())
                saveFile("weight.txt", weight.toString()+"\t"+nowDate)

                val intent = Intent(this, frmCalorieView::class.java)
                startActivity(intent)
            }else {
                //入力ミスがあった場合アラートダイアログの表示
                AlertDialog.Builder(this).setTitle("Error!").setMessage("正しく項目を埋めてください").setPositiveButton("OK",null).show()
                error = 0
            }
        }

        backbt2.setOnClickListener {
            finish()
        }
    }

    //ファイル書き込み
    private fun saveFile(fileName: String, num: String) {
        try {
            openFileOutput( fileName, Context.MODE_PRIVATE).use {
                    fileOutputstream -> fileOutputstream.write(num.toByteArray()) }
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    //ファイル読み込み
    private fun readFile(fileName: String): ArrayList<String> {
        val text: ArrayList<String> = arrayListOf()

        try {
            openFileInput(fileName).use { fileInputStream ->
                BufferedReader(
                    InputStreamReader(fileInputStream, StandardCharsets.UTF_8)
                ).use { br ->
                    var line = br.readLine()
                    while(line != null) {
                        text.add(line)
                        line = br.readLine()
                    }
                }
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }
        return text
    }
}