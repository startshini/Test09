@file:Suppress("ClassName")

package com.example.dfs

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

class frmWeightGraph : AppCompatActivity() {
    private lateinit var file1: File

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_frm_weight_graph)

        val textView = findViewById<TextView>(R.id.stateText)
        val editText = findViewById<EditText>(R.id.weightInput)
        val buttonSave = findViewById<Button>(R.id.ButtonSave)
        val context: Context = applicationContext

        buttonSave.setOnClickListener {
            val calendar: Calendar = Calendar.getInstance(TimeZone.getTimeZone("Asia/Tokyo"), Locale.JAPAN)
            val date: String = calendar.get(Calendar.YEAR).toString() + "-" + (calendar.get(Calendar.MONTH) + 1).toString() + "-" + calendar.get(
                Calendar.DAY_OF_MONTH).toString()
            // エディットテキストのテキストを取得
            val text = editText.text.toString()
            val arrayList: ArrayList<String> = ArrayList(listOf(text, date))
            file1 = File(context.filesDir, "weight.txt")
            WeightDataProc.saveArrayFile(arrayList, file1)
            if (text.isEmpty()) textView.setText(R.string.no_text)
            else textView.setText(R.string.saved)
            WeightGraphDraw(file1)
        }

        val calBt : Button = findViewById(R.id.calBt)
        val traBt : Button = findViewById(R.id.traBt)
        val graBt : Button = findViewById(R.id.graBt)
        val remBt : Button = findViewById(R.id.remBt)

        calBt.setOnClickListener {
            val intent = Intent(this,frmCalorieView::class.java)
            startActivity(intent)
        }

        traBt.setOnClickListener {
            val intent = Intent(this,frmTrainingView::class.java)
            startActivity(intent)
        }

        graBt.setOnClickListener {
            val intent = Intent(this,frmWeightGraph::class.java)
            startActivity(intent)
        }

        remBt.setOnClickListener {
            val intent = Intent(this,frmRemindView::class.java)
            startActivity(intent)
        }
    }
}