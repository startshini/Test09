@file:Suppress("frmWeightGraph")

package com.example.dfs

import android.content.Context
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.formatter.ValueFormatter
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet
import java.io.File
import java.sql.Date
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

class WeightGraphDraw(private var file1: File) : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_frm_weight_graph)
        val context: Context = applicationContext

        //グラフに表示するためのデータを格納
        file1 = File(context.filesDir, "weight.txt")
        var entries = ArrayList<Entry>()
        val list = WeightDataProc.readArrayFile(file1)
        list.reverse()
        
        val saveDate = ArrayList<String>()
        for (i in 0 .. 10){
            if(list[i] == null){
                entries.add(Entry(i.toFloat(), 0f))
            }else {
                val text = list[i].split("\t")
                entries.add(Entry(i.toFloat(), text[0].toFloat()))
                saveDate.add(text[1])
            }
        }

        //表示するデータをDataSetに追加
        val dataSet = LineDataSet(entries, "Label")

        //DataSetをDataに追加
        val data = LineData(dataSet)

        //ビューを取得
        val chart = findViewById<LineChart>(R.id.chart)

        //ChartにDataを追加
        chart.data = data

        val lineDataSet = LineDataSet(entries, "chart")
        lineDataSet.setDrawValues(false)

        chart.data = LineData(mutableListOf<ILineDataSet>(lineDataSet))
        chart.setDrawGridBackground(false)
        chart.description.isEnabled = false

        chart.legend.apply {
            isEnabled = false
        }

        // X 軸のフォーマッター
        val xAxisFormatter = object : ValueFormatter() {
            private var simpleDateFormat: SimpleDateFormat = SimpleDateFormat("M/d", Locale.getDefault())

            override fun getFormattedValue(value: Float): String {
                val date = saveDate[value.toInt()]
                return simpleDateFormat.format(date)
            }
        }

        // X 軸の設定
        chart.xAxis.apply {
            position = XAxis.XAxisPosition.BOTTOM
            valueFormatter = xAxisFormatter
            setDrawGridLines(false)
        }

        // Y 軸（左）の設定
        chart.axisLeft.apply {
            setDrawGridLines(true)
            axisMinimum = 0f
        }

        // Y 軸（右）の設定
        chart.axisRight.apply {
            isEnabled = false
        }

        //チャートを更新
        chart.invalidate()
    }
}