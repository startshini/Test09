package com.example.dfs

import android.content.*
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import java.io.*
import java.nio.charset.StandardCharsets

class frmCalorieBurnedInput : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_frm_calorie_burned_input)

        val backBt2 : Button = findViewById(R.id.backBt)
        val addBt2 : Button = findViewById(R.id.addBt)
        val burnedInput : EditText = findViewById(R.id.BurnedInput)
        val view2 : TextView = findViewById(R.id.View)
        view2.text = readFile("burnedCalorie.txt")
        var burnedNum = readFile("burnedCalorie.txt").toString().toInt()

        addBt2.setOnClickListener {
            burnedNum += burnedInput.text.toString().toInt()
            saveFile("burnedCalorie.txt",burnedNum)
            view2.text = readFile("burnedCalorie.txt")
            burnedInput.text = null
        }

        backBt2.setOnClickListener {
            saveFile("burnedCalorie.txt",burnedNum)
            val intent = Intent(this,frmCalorieView::class.java)
            startActivity(intent)
        }
    }

    private fun saveFile(fileName: String, num: Int) {
        val str:String = num.toString()
        try {
            openFileOutput( fileName, Context.MODE_PRIVATE).use {
                    fileOutputstream -> fileOutputstream.write(str.toByteArray()) }
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    private fun readFile(fileName: String): String? {
        var text: String? = null

        try {
            openFileInput(fileName).use { fileInputStream ->
                BufferedReader(
                    InputStreamReader(fileInputStream, StandardCharsets.UTF_8)
                ).use { reader ->
                    var lineBuffer: String?
                    while (reader.readLine().also { lineBuffer = it } != null) {
                        text = lineBuffer
                    }
                }
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }
        return text
    }
}
