package com.example.dfs

import android.content.*
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import java.io.*
import java.nio.charset.StandardCharsets
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

class frmCalorieBurnedInput : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_frm_calorie_burned_input)

        val backBt2 : Button = findViewById(R.id.backBt)
        val addBt2 : Button = findViewById(R.id.addBt)
        val burnedInput : EditText = findViewById(R.id.BurnedInput)
        val view2 : TextView = findViewById(R.id.View)

        val buttonA : Button = findViewById(R.id.buttonA)
        val buttonB : Button = findViewById(R.id.buttonB)
        val buttonC : Button = findViewById(R.id.buttonC)
        val buttonD : Button = findViewById(R.id.buttonD)
        val buttonE : Button = findViewById(R.id.buttonE)
        val buttonF : Button = findViewById(R.id.buttonF)
        val buttonG : Button = findViewById(R.id.buttonG)
        val buttonH : Button = findViewById(R.id.buttonH)
        val buttonI : Button = findViewById(R.id.buttonI)

        view2.text = readFile("burnedCalorie.txt")
        var burnedNum = readFile("burnedCalorie.txt").toString().toInt()
        val calendar: Calendar = Calendar.getInstance(TimeZone.getTimeZone("Asia/Tokyo"), Locale.JAPAN)
        val date: String = calendar.get(Calendar.YEAR).toString() + "-" + (calendar.get(Calendar.MONTH) + 1).toString() + "-" + calendar.get(
            Calendar.DAY_OF_MONTH).toString()


        addBt2.setOnClickListener {
            burnedNum += burnedInput.text.toString().toInt()
            val burnedInfo: String = burnedNum.toString() + "\n" + date + "\n" + calendar.get(Calendar.HOUR_OF_DAY).toString() + "\n" + calendar.get(Calendar.MINUTE).toString()
            saveFile("burnedCalorie.txt",burnedNum.toString())
            saveFile("burnedCalorieInfo.txt",burnedInfo)
            view2.text = readFile("burnedCalorie.txt")
            burnedInput.text = null
        }

        buttonA.setOnClickListener {
            burnedNum += 250
            val burnedInfo: String = burnedNum.toString() + "\n" + date + "\n" + calendar.get(Calendar.HOUR_OF_DAY).toString() + "\n" + calendar.get(Calendar.MINUTE).toString()
            saveFile("burnedCalorie.txt",burnedNum.toString())
            saveFile("burnedCalorieInfo.txt",burnedInfo)
            view2.text = readFile("burnedCalorie.txt")
            burnedInput.text = null
        }

        buttonB.setOnClickListener {
            burnedNum += 40
            val burnedInfo: String = burnedNum.toString() + "\n" + date + "\n" + calendar.get(Calendar.HOUR_OF_DAY).toString() + "\n" + calendar.get(Calendar.MINUTE).toString()
            saveFile("burnedCalorie.txt",burnedNum.toString())
            saveFile("burnedCalorieInfo.txt",burnedInfo)
            view2.text = readFile("burnedCalorie.txt")
            burnedInput.text = null
        }

        buttonC.setOnClickListener {
            burnedNum += 60
            val burnedInfo: String = burnedNum.toString() + "\n" + date + "\n" + calendar.get(Calendar.HOUR_OF_DAY).toString() + "\n" + calendar.get(Calendar.MINUTE).toString()
            saveFile("burnedCalorie.txt",burnedNum.toString())
            saveFile("burnedCalorieInfo.txt",burnedInfo)
            view2.text = readFile("burnedCalorie.txt")
            burnedInput.text = null
        }

        buttonD.setOnClickListener {
            burnedNum += 42
            val burnedInfo: String = burnedNum.toString() + "\n" + date + "\n" + calendar.get(Calendar.HOUR_OF_DAY).toString() + "\n" + calendar.get(Calendar.MINUTE).toString()
            saveFile("burnedCalorie.txt",burnedNum.toString())
            saveFile("burnedCalorieInfo.txt",burnedInfo)
            view2.text = readFile("burnedCalorie.txt")
            burnedInput.text = null
        }

        buttonE.setOnClickListener {
            burnedNum += 20
            val burnedInfo: String = burnedNum.toString() + "\n" + date + "\n" + calendar.get(Calendar.HOUR_OF_DAY).toString() + "\n" + calendar.get(Calendar.MINUTE).toString()
            saveFile("burnedCalorie.txt",burnedNum.toString())
            saveFile("burnedCalorieInfo.txt",burnedInfo)
            view2.text = readFile("burnedCalorie.txt")
            burnedInput.text = null
        }

        buttonF.setOnClickListener {
            burnedNum += 26
            val burnedInfo: String = burnedNum.toString() + "\n" + date + "\n" + calendar.get(Calendar.HOUR_OF_DAY).toString() + "\n" + calendar.get(Calendar.MINUTE).toString()
            saveFile("burnedCalorie.txt",burnedNum.toString())
            saveFile("burnedCalorieInfo.txt",burnedInfo)
            view2.text = readFile("burnedCalorie.txt")
            burnedInput.text = null
        }

        buttonG.setOnClickListener {
            burnedNum += 15
            val burnedInfo: String = burnedNum.toString() + "\n" + date + "\n" + calendar.get(Calendar.HOUR_OF_DAY).toString() + "\n" + calendar.get(Calendar.MINUTE).toString()
            saveFile("burnedCalorie.txt",burnedNum.toString())
            saveFile("burnedCalorieInfo.txt",burnedInfo)
            view2.text = readFile("burnedCalorie.txt")
            burnedInput.text = null
        }

        buttonH.setOnClickListener {
            burnedNum += 15
            val burnedInfo: String = burnedNum.toString() + "\n" + date + "\n" + calendar.get(Calendar.HOUR_OF_DAY).toString() + "\n" + calendar.get(Calendar.MINUTE).toString()
            saveFile("burnedCalorie.txt",burnedNum.toString())
            saveFile("burnedCalorieInfo.txt",burnedInfo)
            view2.text = readFile("burnedCalorie.txt")
            burnedInput.text = null
        }

        buttonI.setOnClickListener {
            burnedNum += 42
            val burnedInfo: String = burnedNum.toString() + "\n" + date + "\n" + calendar.get(Calendar.HOUR_OF_DAY).toString() + "\n" + calendar.get(Calendar.MINUTE).toString()
            saveFile("burnedCalorie.txt",burnedNum.toString())
            saveFile("burnedCalorieInfo.txt",burnedInfo)
            view2.text = readFile("burnedCalorie.txt")
            burnedInput.text = null
        }

        backBt2.setOnClickListener {
            saveFile("burnedCalorie.txt",burnedNum.toString())
            val intent = Intent(this,frmCalorieView::class.java)
            startActivity(intent)
        }


    }

    private fun saveFile(fileName: String, str: String) {
        try {
            openFileOutput( fileName, Context.MODE_PRIVATE).use {
                    fileOutputstream -> fileOutputstream.write(str.toByteArray()) }
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    private fun readFile(fileName: String): String? {
        var text: String? = null

        try {
            openFileInput(fileName).use { fileInputStream ->
                BufferedReader(
                    InputStreamReader(fileInputStream, StandardCharsets.UTF_8)
                ).use { reader ->
                    var lineBuffer: String?
                    while (reader.readLine().also { lineBuffer = it } != null) {
                        text = lineBuffer
                    }
                }
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }
        return text
    }
}
