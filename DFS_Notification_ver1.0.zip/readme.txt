app/manifests/AndroidManifest.xml

<manifest ....>
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
    <uses-permission android:name="android.permission.VIBRATE" />
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />

上の<uses から始まる三行をmanifest内に追記

<application>
.
.
.
.
         <service
            android:name=".NotificationJS"
            android:permission="android.permission.BIND_JOB_SERVICE" />
</application>

上のように<application>内に<service から始まる三行を追記

--------------------------------------------------------------------------------------

Gradle Scripts/build.gradle(Module:app)
ファイルの最後に
dependencies {
    implementation 'androidx.core:core-ktx:1.8.0'
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'com.google.android.material:material:1.5.0'
    implementation 'androidx.constraintlayout:constraintlayout:2.1.4'
    testImplementation 'junit:junit:4.13.2'
    androidTestImplementation 'androidx.test.ext:junit:1.1.5'
    androidTestImplementation 'androidx.test.espresso:espresso-core:3.5.1'
    implementation "androidx.work:work-runtime-ktx:2.7.0"
}
を追記
すでに記述されていたら、無い行をdependencies内部に追記
数字は違うけど書いてる文字は同じとかだったら変えないほうがいいかも

吹き出しの画像はResource Manager(画面左端に縦書きで小さく書かれてる)から登録してください