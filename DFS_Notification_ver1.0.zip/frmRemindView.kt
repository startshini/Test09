package com.example.dfs

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.job.JobInfo
import android.app.job.JobScheduler
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.icu.util.TimeUnit
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup.LayoutParams
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.Space
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.io.FileReader
import java.io.FileWriter
import java.io.IOException
import java.time.LocalDate
import java.util.Calendar
import com.example.dfs.NotificationJS


class frmRemindView : AppCompatActivity() {
    private lateinit var file1: File
    private lateinit var file2: File
    private lateinit var file3: File
    private lateinit var file4: File
    private var text = ArrayList<String>()
    private val ALERT_SERVICE_JOB_ID = 1
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_frm_remind_view)

        val calBt : Button = findViewById(R.id.calBt)
        val traBt : Button = findViewById(R.id.traBt)
        val graBt : Button = findViewById(R.id.graBt)
        val remBt : Button = findViewById(R.id.remBt)
        var currentDay = LocalDate.now()
        val context: Context = applicationContext

        //日付が変わったか判定用のファイル
        file1 = File(context.filesDir, "RemindDataDay.txt")
        //その日のリマインド履歴を格納するファイル
        file2 = File(context.filesDir, "RemindDataStr.txt")
        //摂取カロリー日付付き
        file3 = File(context.filesDir, "intakeCalorieInfo.txt")
        //消費カロリー日付付き
        file4 = File(context.filesDir, "burnedCalorieInfo.txt")
        text.clear()
        //バックグラウンドの定期処理の実行
        scheduleService()

        //日付判定ファイルから呼び出し
        var day = readFile(file1).toString()
        //もし日付判定ファイルの日付と今日の日付が同じなら今日の分のリマインド履歴を読み込む
        if(day == currentDay.toString()){
            text = readArrayFile(file2)
            for (i in text.indices){
                insertRemindChat(text[i])
            }
        //違うなら日付判定ファイルに今日の日付を保存、昨日までのリマインド履歴を削除
        } else{
            saveFile(currentDay.toString(), file1)
            //テキスト内の内容を削除
            clearText(file2)
        }

        calBt.setOnClickListener {
            val intent = Intent(this,frmCalorieView::class.java)
            startActivity(intent)
        }

        traBt.setOnClickListener {
            val intent = Intent(this,frmTrainingView::class.java)
            startActivity(intent)
        }

        graBt.setOnClickListener {
            val intent = Intent(this,frmWeightGraph::class.java)
            startActivity(intent)
        }

        remBt.setOnClickListener {
            val intent = Intent(this,frmRemindView::class.java)
            startActivity(intent)
        }
    }
    //画面に吹き出しとテキストを追加
    private fun insertRemindChat(remindchat: String) {
        val relativeLayout = RelativeLayout(this)
        relativeLayout.layoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)

        val linearLayout = LinearLayout(this)
        linearLayout.layoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)
        linearLayout.orientation = LinearLayout.VERTICAL

        val imageView = ImageView(this)
        imageView.setImageResource(R.drawable.hukidasi)
        imageView.layoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)

        val textLL = findViewById<LinearLayout>(R.id.textLL)
        //テキストビューを生成
        val textView = TextView(this)
        //生成されたテキストに入力されたテキストを代入
        textView.text = remindchat
        //テキストビューのサイズを修正
        textView.textSize = 20f

        textView.layoutParams = RelativeLayout.LayoutParams(
            LayoutParams.WRAP_CONTENT,
            LayoutParams.WRAP_CONTENT
        )

        val params = RelativeLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)
        params.addRule(RelativeLayout.CENTER_IN_PARENT, RelativeLayout.TRUE)

        relativeLayout.addView(imageView)
        relativeLayout.addView(textView, params)

        textLL.addView(relativeLayout)

        val sp = Space(this)
        textLL.addView(sp, FrameLayout.LayoutParams(20, 20))
    }
    private fun scheduleService(){
        val scheduler = getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
        /// サービスが動いているかの状態を取得
        var hasBeenScheduled = false
        for (jobInfo in scheduler.allPendingJobs) {
            if (jobInfo.id == ALERT_SERVICE_JOB_ID) {
                hasBeenScheduled = true
                break
            }
        }
        /// 未稼働ならスケジュール登録
        if( ! hasBeenScheduled) {
            val componentName = ComponentName(this, NotificationJS::class.java)
            val jobInfo = JobInfo.Builder(ALERT_SERVICE_JOB_ID, componentName)
                .apply {
                    setBackoffCriteria(10000, JobInfo.BACKOFF_POLICY_LINEAR);
                    setPersisted(true)
                    setPeriodic(1000 * 60 * 60)  //60分
                    setRequiredNetworkType(JobInfo.NETWORK_TYPE_NONE)
                    setRequiresCharging(false)
                }.build()
            scheduler.schedule(jobInfo)
        }
    }
    //RemindStrファイルを読み出し
    private fun readArrayFile(file : File): ArrayList<String> {
        var text: ArrayList<String> = arrayListOf()
        try {
            var br = BufferedReader(FileReader(file))
            var line = br.readLine()
            while (line != null) {
                text.add(line)
                line = br.readLine()
            }
            br.close()
        } catch (e: IOException) {
            e.printStackTrace()
        }
        return text
    }
    //dayファイルを保存
    private fun saveFile(str: String?, file:File) {
        try {
            //ファイルを追記モードで開く
            val fileWriter = FileWriter(file, false)
            val bufferedWriter = BufferedWriter(fileWriter)
            //空文字をファイルに書き込む
            bufferedWriter.write(str)
            //ファイルを閉じる
            bufferedWriter.close()
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }
    //dayファイルを読み出し
    private fun readFile(file:File): String? {
        var tmptext: String? = null

        try {
            var br = BufferedReader(FileReader(file))
            tmptext = br.readLine()
            br.close()
        } catch (e: IOException) {
            e.printStackTrace()
        }
        return tmptext
    }
    //テキストファイル内の文字列をすべて削除
    private fun clearText(file:File) {
        try {
            //ファイルを追記モードで開く
            val fileWriter = FileWriter(file, false)
            val bufferedWriter = BufferedWriter(fileWriter)
            //空文字をファイルに書き込む
            bufferedWriter.write("")
            //ファイルを閉じる
            bufferedWriter.close()
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }
}