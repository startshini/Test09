package com.example.dfs

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.formatter.ValueFormatter
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import  android.content.Context

class WeightGraphDraw2 : AppCompatActivity() {

    companion object {
        fun GraphDraw(lineChart: LineChart, file1: File) {
/*
            //表示用サンプルデータの作成//
            val x = listOf<Float>(1f, 2f, 3f, 5f, 8f, 13f, 21f, 34f)//X軸データ
            val y = x.map{it*it}//Y軸データ（X軸の2乗）

            //①Entryにデータ格納
            var entryList = mutableListOf<Entry>()//1本目の線
            for(i in x.indices){
                entryList.add(
                    Entry(x[i], y[i])
                )
            }

 */
            //グラフに表示するためのデータを格納
            val entryList = mutableListOf<Entry>()
            val list = WeightDataProc.readArrayFile(file1)
            list.reverse()

            val saveDate = ArrayList<String>()
            if(list.size <= 1){
                for(i in 0..10){
                    entryList.add(Entry(i.toFloat(), 0f))
                }
            }else if(list.size<10){
                for (i in 0 until list.size) {
                    val text = list[i].split("\t")
                    entryList.add(Entry(i.toFloat(), text[0].toFloat()))
                    saveDate.add(text[1])
                }
                for(i in list.size..10){
                    entryList.add(Entry(i.toFloat(), 0f))
                }
            }else{
                for (i in 0..10) {
                    val text = list[i].split("\t")
                    entryList.add(Entry(i.toFloat(), text[0].toFloat()))
                    saveDate.add(text[1])
                }
            }

            //LineDataSetのList
            val lineDataSets = mutableListOf<ILineDataSet>()
            //②DataSetにデータ格納
            val lineDataSet = LineDataSet(entryList, "square")
            //③DataSetにフォーマット指定(3章で詳説)
            lineDataSet.color = Color.BLUE
            //リストに格納
            lineDataSets.add(lineDataSet)

            //④LineDataにLineDataSet格納
            val lineData = LineData(lineDataSets)
            //⑤LineChartにLineData格納

            lineChart.data = lineData
            //⑥Chartのフォーマット指定(3章で詳説)
            //X軸の設定
            lineChart.xAxis.apply {
                isEnabled = true
                textColor = Color.BLACK
            }
            //⑦linechart更新
            lineChart.invalidate()
        }
    }
}