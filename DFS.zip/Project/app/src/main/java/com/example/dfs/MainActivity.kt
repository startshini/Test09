package com.example.dfs

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import java.time.format.DateTimeFormatter

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val bt2 : Button = findViewById(R.id.button2)
        var txt7 : TextView = findViewById(R.id.textView7)

        bt2.setOnClickListener {
            txt7.text = DateTimeFormatter.ofPattern("yyyy/MM/dd").toString()
        }
    }
}