package com.example.dfs

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class frmCalorieView : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_frm_calorie_view)

        //viewから取得
        val calBt : Button = findViewById(R.id.calBt)
        val traBt : Button = findViewById(R.id.traBt)
        val graBt : Button = findViewById(R.id.graBt)
        val remBt : Button = findViewById(R.id.remBt)
        val infBt : Button = findViewById(R.id.infBt)
        val intBT : Button = findViewById(R.id.intBt)
        val burBt : Button = findViewById(R.id.burBt)
        var limText : TextView = findViewById(R.id.limText)
        var intText : TextView = findViewById(R.id.intText)
        var burText : TextView = findViewById(R.id.burText)
        val Calorie = Common.getInstance()

        limText.text = "${Calorie.limitCalorie}"
        intText.text = "${Calorie.IntakeCalorie}"
        burText.text = "${Calorie.BurnedCalorie}"


        calBt.setOnClickListener {
            val intent = Intent(this,frmCalorieView::class.java)
            startActivity(intent)
        }

        traBt.setOnClickListener {
            val intent = Intent(this,frmTrainingView::class.java)
            startActivity(intent)
        }

        graBt.setOnClickListener {
            val intent = Intent(this,frmWeightGraph::class.java)
            startActivity(intent)
        }

        remBt.setOnClickListener {
            val intent = Intent(this,frmRemindView::class.java)
            startActivity(intent)
        }

        infBt.setOnClickListener {
            val intent = Intent(this,frmUserInfoInput::class.java)
            startActivity(intent)
        }

        intBT.setOnClickListener {
            val intent = Intent(this,frmCalorieIntakeInput::class.java)
            startActivity(intent)
        }

        burBt.setOnClickListener {
            val intent = Intent(this,frmCalorieBurnedInput::class.java)
            startActivity(intent)
        }
    }
}