package com.example.dfs

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class frmCalorieBurnedInput : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_frm_calorie_burned_input)

        val backBt : Button = findViewById(R.id.backBt)
        val input : Button = findViewById(R.id.Input)
        var burtxt : EditText = findViewById(R.id.burTxt)
        var view : TextView = findViewById(R.id.BurView)
        var Calorie = Common.getInstance()
        view.text = "${Calorie.BurnedCalorie}"
        var BurnedNum : Int = Calorie.BurnedCalorie

        input.setOnClickListener {
            BurnedNum += burtxt.text.toString().toInt()
            view.text = "$BurnedNum"
            burtxt.text = null
        }


        backBt.setOnClickListener {
            Calorie.BurnedCalorie = BurnedNum
            val intent = Intent(this,frmCalorieView::class.java)
            startActivity(intent)
        }
    }
}