package com.example.dfs

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import java.time.LocalDate

class frmUserInfoInput : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_frm_user_info_input)

        val backBt : Button = findViewById(R.id.backBt)
        val BirInp : EditText = findViewById(R.id.BirInp)
        val HeiInp : EditText = findViewById(R.id.HeiInp)
        val WeiInp : EditText = findViewById(R.id.WeiInp)
        val Gender : RadioGroup = findViewById(R.id.Gender)
        val Date : LocalDate = LocalDate.now()
        val Calorie = Common.getInstance()
        var birErr : Int = 0
        var gen : Int = -1
        var Age : Int = 0

        Gender.setOnCheckedChangeListener { group, checkedId ->
            if(checkedId == R.id.male) {
                gen = 0
            }
            if(checkedId == R.id.female) {
                gen = 1
            }
        }


        backBt.setOnClickListener {
            var BirthDate = BirInp.text.toString()
            val birth = BirthDate.split("/")
            val CurrentDate = Date.toString()
            val current = CurrentDate.split("-")

            if (birth[0].toInt() > current[0].toInt()) {
                birErr = 1
            } else {
                Age = current[0].toInt() - birth[0].toInt()
                if (current[1].toInt() > birth[1].toInt()) {
                    Age -= 1
                } else {
                    if (current[2].toInt() > birth[2].toInt()) {
                        Age -= 1
                    }
                }
            }

            var weight : Double = WeiInp.text.toString().toDouble()
            var height : Double = HeiInp.text.toString().toDouble()

            if(gen == 0) {
                Calorie.limitCalorie = ((13.397 * weight + 4.799 * height - 5.677 * Age + 88.362) + (3 * weight * 1.05)).toInt()
                val intent = Intent(this,frmCalorieView::class.java)
                startActivity(intent)
            }
            else if(gen == 1) {
                Calorie.limitCalorie = ((9.247 * weight + 3.098 * height - 4.33 * Age + 447.593) + (3 * weight * 1.05)).toInt()
                val intent = Intent(this,frmCalorieView::class.java)
                startActivity(intent)
            }
        }
    }
}