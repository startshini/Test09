package com.example.dfs

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.io.FileReader
import java.io.FileWriter
import java.io.IOException
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

@SuppressLint("SpecifyJobSchedulerIdRange")
public class NotificationJS : JobService() {
    private var channelId = "NOTIFICATION"
    private lateinit var file2: File
    private lateinit var file3: File
    private lateinit var file4: File
    private lateinit var file5: File
    override fun onStopJob(params: JobParameters?): Boolean {
        jobFinished(params, false)
        return true
    }

    override fun onStartJob(params: JobParameters?): Boolean {
        //今日の日付取得
        val calendar: Calendar = Calendar.getInstance(TimeZone.getTimeZone("Asia/Tokyo"), Locale.JAPAN)
        val currentDay: String = calendar.get(Calendar.YEAR).toString() + "-" + (calendar.get(Calendar.MONTH) + 1).toString() + "-" + calendar.get(
            Calendar.DAY_OF_MONTH).toString()
        //現在の時刻を取得
        var currentTime = LocalTime.now()
        //17:00の時刻を作成
        val bcTime17 = LocalTime.of(17, 0)
        val context: Context = applicationContext
        //その日のリマインド履歴を格納するファイル
        file2 = File(context.filesDir, "RemindDataStr.txt")
        //摂取カロリー日付付き
        file3 = File(context.filesDir, "intakeCalorieInfo.txt")
        //消費カロリー日付付き
        file4 = File(context.filesDir, "burnedCalorieInfo.txt")
        //一日の上限カロリー
        file5 = File(context.filesDir, "limitCalorie.txt")
        var limitC = readFile(file5)?.toInt()
        //消費カロリーに関する情報を取得
        var tmp1: ArrayList<String> = ArrayList<String>(readArrayFile(file4))
        //摂取カロリーに関する情報を取得
        var tmp2: ArrayList<String> = ArrayList<String>(readArrayFile(file3))

        //通知情報
        var channelName = ""
        var title = ""
        var message = ""

        //消費カロリーファイルの日付が今日ではないとき
        if(tmp1[1] != currentDay) {
            //かつ17時を過ぎたとき運動するように通知する
            if(currentTime.isAfter(bcTime17)){
                //通知を表示
                channelName = "NTFBurnedCal"
                title = "運動をしましょう！"
                message = "今日はまだ運動をしていないようです。カロリーを消費しましょう！"
                showNotification(this, channelName, title, message)
                appendTextFile(title,file2)
            }
        //消費カロリーファイルの日付が今日であり、かつ消費カロリーが足りてないとき
        }else{
            if(limitC != null && (limitC - tmp2[0].toInt()) < 0){
                //通知を表示
                channelName = "NTFBurnedCal"
                title = "運動をしましょう！"
                message = "一日の摂取限度カロリーを超えているようです。カロリーを消費しましょう！"
                showNotification(this, channelName, title, message)
                appendTextFile(title,file2)
            }
        }
        val icTime7 = LocalTime.of(7, 0)
        val icTime9 = LocalTime.of(9, 0)
        val icTime11 = LocalTime.of(11, 0)
        val icTime12 = LocalTime.of(12, 0)
        val icTime14 = LocalTime.of(14, 0)
        val icTime16 = LocalTime.of(16, 0)
        val icTime19 = LocalTime.of(19, 0)
        val icTime21 = LocalTime.of(21, 0)
        val icTime23 = LocalTime.of(23, 0)

        val icTime0 = LocalTime.of(0, 0)
        //摂取カロリーファイルに書き込まれた時刻を取得
        var icTime = LocalTime.of(tmp2[2].toInt(), tmp2[3].toInt())
        //摂取カロリーファイルの日付が今日であるとき
        if(tmp2[1] == currentDay){
            //かつ現在時刻が9:00と11:00の間の場合で摂取カロリーファイルの時刻が7時より前の時
            if((currentTime.isAfter(icTime9) && currentTime.isBefore(icTime11))) {
                if(icTime.isBefore(icTime7)) {
                    //通知を表示
                    channelName = "NTFIntakeCalAM"
                    title = "朝ごはんは食べましたか？"
                    message = "朝ごはんの入力がまだのようです。ごはんをたべてカロリーを摂取しましょう！"
                    showNotification(this, channelName, title, message)
                    appendTextFile(title, file2)
                }
            }
                //かつ現在時刻が14:00と16:00の間の場合で摂取カロリーファイルの時刻が12時より前の時
            else if(currentTime.isAfter(icTime14) && currentTime.isBefore(icTime16)){
                if(icTime.isBefore(icTime12)) {
                    //通知を表示
                    channelName = "NTFIntakeCalNOON"
                    title = "昼ごはんは食べましたか？"
                    message = "昼食の入力がまだのようです。カロリーを摂取しましょう！"
                    showNotification(this, channelName, title, message)
                    appendTextFile(title, file2)
                }
                //かつ現在時刻が21:00と23:00の間の場合で摂取カロリーファイルの時刻が19時より前の時
            }else if(currentTime.isAfter(icTime21) && currentTime.isBefore(icTime23)){
                if(icTime.isBefore(icTime19)) {
                    //通知を表示
                    channelName = "NTFIntakeCalPM"
                    title = "夜ごはんは食べましたか？"
                    message = "夕食の入力がまだのようです。カロリーを摂取しましょう！"
                    showNotification(this, channelName, title, message)
                    appendTextFile(title, file2)
                }
            }

        //今日じゃなかったら
        }else if(tmp2[1] != currentDay){
            if(currentTime.isAfter(icTime9)){
                //通知を表示
                channelName = "NTFIntakeCalAM"
                title = "朝ごはんは食べましたか？"
                message = "朝食の入力がまだのようです。ごはんをたべてカロリーを摂取しましょう！"
                showNotification(this, channelName, title, message)
                appendTextFile(title,file2)
            }

        }
        return false
    }
    private fun showNotification(context: Context, channelName: String, title: String, message: String) {
        //Notification Channelの作成
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel(channelId, channelName, importance)
            val notificationManager = context.getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }
        val intent = Intent(this, frmCalorieView::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
        )

        //通知のビルドと表示
        val builder = NotificationCompat.Builder(context, channelId)
            //通知のアイコン
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            //通知のタイトル
            .setContentTitle(title)
            //通知のメッセージ
            .setContentText(message)
            //通知の優先度
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            //通知をタップしたら自動的に消して、アプリを起動する
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)

        val notificationManager = NotificationManagerCompat.from(context)
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return
        }
        notificationManager.notify(0, builder.build())
    }
    private fun readArrayFile(file : File): ArrayList<String> {
        var text: ArrayList<String> = arrayListOf()
        try {
            val br = BufferedReader(FileReader(file))
            var line = br.readLine()
            while (line != null) {
                text.add(line)
                line = br.readLine()
            }
            br.close()
        } catch (e: IOException) {
            e.printStackTrace()
        }
        return text
    }
    //一行読み込み
    private fun readFile(file:File): String? {
        var tmptext: String? = null

        try {
            var br = BufferedReader(FileReader(file))
            tmptext = br.readLine()
            br.close()
        } catch (e: IOException) {
            e.printStackTrace()
        }
        return tmptext
    }
    //テキストファイルに追加で書き込む
    private fun appendTextFile(text: String, file: File) {
        try {
            //ファイルを追記モードで開く
            val fileWriter = FileWriter(file, true)
            val bufferedWriter = BufferedWriter(fileWriter)

            //文字列と改行をファイルに書き込む
            bufferedWriter.write(text)
            bufferedWriter.newLine()

            //ファイルを閉じる
            bufferedWriter.close()
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }
}