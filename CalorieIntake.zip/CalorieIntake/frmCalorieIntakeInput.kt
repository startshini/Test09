package com.example.dfs

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Space
import android.widget.TextView

class frmCalorieIntakeInput : AppCompatActivity() {
    private fun insert_value(value : String){ //引数２つを横に並べる
        val text_in = findViewById<LinearLayout>(R.id.text_in)   //縦のレイアウト
        //val text_hor = findViewById<LinearLayout>(R.id.text_hor)  //横のレイアウト
        val textView = TextView(this)
        val sp = Space(this)
        textView.text = value
        text_in.addView(textView)  //in->horに変更した
        text_in.addView(sp, FrameLayout.LayoutParams(300, 10))
        //val sp = Space(this)
        //text_hor.addView(sp, FrameLayout.LayoutParams(40, 40))
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_frm_calorie_intake_input)

        val backBt : Button = findViewById(R.id.backBt)  //完了ボタン
        val addbt : Button = findViewById(R.id.addBt)    //入力ボタン
        var intakeInput : EditText = findViewById(R.id.IntakeInput)    //カロリーinput
        var takemealInput: EditText = findViewById(R.id.TakeMealInput) //食事input

        val text_in = findViewById<LinearLayout>(R.id.text_in)   //縦のレイアウト

        //var view : TextView = findViewById(R.id.View)
        var Calorie = Common.getInstance()
        //view.text = "${Calorie.IntakeCalorie}"
        var IntakeNum : Int = Calorie.IntakeCalorie.toInt()
        var i : Int = 1 //メニューの番号
        //insert_value("Muscle")
        addbt.setOnClickListener {
            IntakeNum += intakeInput.text.toString().toInt()
            //view.text = "$IntakeNum"
            //insert_value("Muscle")
            insert_value("メニュー" + i + "：" + takemealInput.getText().toString() +
                    "  --------->  " + intakeInput.getText().toString() + "kcal")
            insert_value("-----------------------------------------------------------------------------" +
                    "-----------")
            //insert_value(intakeInput.getText().toString() + "kcal")
            intakeInput.text = null
            takemealInput.text = null
            i = i + 1
        }

        backBt.setOnClickListener {
            Calorie.IntakeCalorie = IntakeNum
            val intent = Intent(this,frmCalorieView::class.java)
            startActivity(intent)
        }


    }
}