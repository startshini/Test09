package com.example.dfs

import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.io.FileReader
import java.io.FileWriter
import java.io.IOException
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

class WeightDataProc {

    companion object {
        // RemindStrファイルを保存
        fun saveArrayFile(text: ArrayList<String>, file: File) {
            val calendar: Calendar = Calendar.getInstance(TimeZone.getTimeZone("Asia/Tokyo"), Locale.JAPAN)
            val nowDate: String = calendar.get(Calendar.YEAR).toString() + "-" + (calendar.get(Calendar.MONTH) + 1).toString() + "-" + calendar.get(
                Calendar.DAY_OF_MONTH).toString()

            try {
                BufferedReader(FileReader(file)).use { br ->
                    var line = br.readLine()
                    while (line != null) {
                        text.add(line)
                        line = br.readLine()
                    }
                }
            } catch (e: IOException) {
                e.printStackTrace()
            }

            val str: String = text[text.size - 1]
            val lastLine = str.split("\t")
            if (lastLine[1] == nowDate){
                try {
                    BufferedWriter(FileWriter(file)).use { writer ->
                        val lines = text.size - 1
                        for (i in 0..lines) {
                            writer.write(text[i]+"\t"+nowDate)
                        }
                    }
                } catch (e: IOException) {
                    e.printStackTrace()
                }
            }else {
                try {
                    BufferedWriter(FileWriter(file)).use { writer ->
                        val lines = text.size - 1
                        for (i in 0..lines) {
                            writer.newLine()
                            writer.write(text[i] + "\t" + nowDate)
                        }
                    }
                } catch (e: IOException) {
                    e.printStackTrace()
                }
            }
        }

        // RemindStrファイルを読み出し
        fun readArrayFile(file: File): ArrayList<String> {
            var text: ArrayList<String> = arrayListOf()
            try {
                BufferedReader(FileReader(file)).use { br ->
                    var line = br.readLine()
                    while (line != null) {
                        text.add(line)
                        line = br.readLine()
                    }
                }
            } catch (e: IOException) {
                e.printStackTrace()
            }
            return text
        }
    }
}