package com.example.dfs

import android.content.*
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import java.io.*

class frmUserInfoInput : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_frm_user_info_input)


        val backBt : Button = findViewById(R.id.backBt)
        val BirInp : EditText = findViewById(R.id.BirInp)
        val HeiInp : EditText = findViewById(R.id.HeiInp)
        val WeiInp : EditText = findViewById(R.id.WeiInp)
        val Gender : RadioGroup = findViewById(R.id.Gender)
        var gender : Int = -1
        var age : Int = -1

        Gender.setOnCheckedChangeListener { group, checkedId ->
            if(checkedId == R.id.male) {
                gender = 0
            }
            if(checkedId == R.id.female) {
                gender = 1
            }
        }


        backBt.setOnClickListener {
            val BirthDate = BirInp.text.toString()
            age = Calculation().ageCalc(BirthDate)


            var weight : Double = WeiInp.text.toString().toDouble()
            var height : Double = HeiInp.text.toString().toDouble()

            val limitNum = Calculation().limitCalorieCalc(weight,height,age,gender)

            saveFile("limitCalorie.txt",limitNum)

            val intent = Intent(this, frmCalorieView::class.java)
            startActivity(intent)
        }
    }

    //ファイル入力
    private fun saveFile(fileName: String, num: Int) {
        val str:String = num.toString()
        try {
            openFileOutput( fileName, Context.MODE_PRIVATE).use {
                    fileOutputstream -> fileOutputstream.write(str.toByteArray()) }
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }
}