package com.example.dfs

import android.content.*
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import java.io.*
import java.nio.charset.StandardCharsets

class frmCalorieIntakeInput : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_frm_calorie_intake_input)

        val backBt : Button = findViewById(R.id.backBt)
        val addBt : Button = findViewById(R.id.addBt)
        val intakeInput : EditText = findViewById(R.id.IntakeInput)
        val view : TextView = findViewById(R.id.View)
        view.text = readFile("intakeCalorie.txt")
        var intakeNum = readFile("intakeCalorie.txt").toString().toInt()

        addBt.setOnClickListener {
            intakeNum += intakeInput.text.toString().toInt()
            saveFile("intakeCalorie.txt",intakeNum)
            view.text = readFile("intakeCalorie.txt")
            intakeInput.text = null
        }

        backBt.setOnClickListener {
            saveFile("intakeCalorie.txt",intakeNum)
            val intent = Intent(this, frmCalorieView::class.java)
            startActivity(intent)
        }
    }

    private fun saveFile(fileName: String, num: Int) {
        val str:String = num.toString()
        try {
            openFileOutput( fileName, Context.MODE_PRIVATE).use {
                    fileOutputstream -> fileOutputstream.write(str.toByteArray()) }
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    private fun readFile(fileName: String): String? {
        var text: String? = null

        try {
            openFileInput(fileName).use { fileInputStream ->
                BufferedReader(
                    InputStreamReader(fileInputStream, StandardCharsets.UTF_8)
                ).use { reader ->
                    var lineBuffer: String?
                    while (reader.readLine().also { lineBuffer = it } != null) {
                        text = lineBuffer
                    }
                }
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }
        return text
    }
}