package com.example.dfs

import android.app.Application

class Common : Application(){
    var limitCalorie : Int = 0
    var IntakeCalorie : Int = 0
    var BurnedCalorie : Int = 0

    companion object {
        private var instance : Common? = null

        fun getInstance() : Common {
            if(instance == null) {
                instance = Common()
            }
            return instance!!
        }
    }
}