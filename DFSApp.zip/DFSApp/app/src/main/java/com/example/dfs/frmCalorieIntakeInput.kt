package com.example.dfs

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class frmCalorieIntakeInput : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_frm_calorie_intake_input)

        val backBt : Button = findViewById(R.id.backBt)
        val addbt : Button = findViewById(R.id.addBt)
        var intakeInput : EditText = findViewById(R.id.IntakeInput)
        var view : TextView = findViewById(R.id.View)
        var Calorie = Common.getInstance()
        view.text = "${Calorie.IntakeCalorie}"
        var IntakeNum : Int = Calorie.IntakeCalorie.toInt()

        addbt.setOnClickListener {
            IntakeNum += intakeInput.text.toString().toInt()
            view.text = "$IntakeNum"
            intakeInput.text = null
        }

        backBt.setOnClickListener {
            Calorie.IntakeCalorie = IntakeNum
            val intent = Intent(this,frmCalorieView::class.java)
            startActivity(intent)
        }
    }
}