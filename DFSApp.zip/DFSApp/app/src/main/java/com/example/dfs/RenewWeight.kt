package com.example.dfs

import androidx.appcompat.app.AppCompatActivity
import android.content.Context
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import org.json.JSONArray
import java.io.*

class RenewWeight : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_frm_weight_graph)

        val textView = findViewById<TextView>(R.id.weightInput)
        val editText = findViewById<TextView>(R.id.weightInput)
        val buttonSave = findViewById<Button>(R.id.ButtonSave)

        buttonSave.setOnClickListener {
            // エディットテキストのテキストを取得
            val text = editText.text.toString()
            // 読み込み
            val arrayList: ArrayList<String> = loadArrayList("weight")
            arrayList.add(text)
            // 保存
            saveArrayList("weight", arrayList)
            if (text.isEmpty()) textView.setText(R.string.no_text)
            else textView.setText(R.string.saved)
        }

        buttonSave.setOnClickListener {
            val arrayList: ArrayList<String> = loadArrayList("weight")
            val str = arrayList[arrayList.lastIndex]
            if (str != null) {
                textView.text = str
            } else {
                textView.setText(R.string.read_error)
            }
        }
    }

    // リストの保存
    private fun saveArrayList(key: String, arrayList: ArrayList<String>) {

        val shardPreferences = this.getPreferences(Context.MODE_PRIVATE)
        val shardPrefEditor = shardPreferences.edit()

        val jsonArray = JSONArray(arrayList)
        shardPrefEditor.putString(key, jsonArray.toString())
        shardPrefEditor.apply()
    }

    // リストの読み込み
    private fun loadArrayList(key: String): ArrayList<String> {

        val shardPreferences = this.getPreferences(Context.MODE_PRIVATE)

        val jsonArray = JSONArray(shardPreferences.getString(key, "[]"));

        val arrayList: ArrayList<String> = ArrayList()

        for (i in 0 until jsonArray.length()) {
            arrayList.add(jsonArray.get(i) as String)
        }

        return arrayList
    }
}
